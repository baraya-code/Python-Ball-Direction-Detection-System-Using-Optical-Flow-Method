                                                    #ukuran kamera 480px.640px

# INTRUKSI DI BAWAH!


from collections import deque
from copy import deepcopy
import numpy as np
import argparse
import math
import cv2
# install lib cv xone
# pip install cvzone
import cvzone
from cvzone.ColorModule import ColorFinder

def nothing(x):
    pass
def track_bar(mirror=False,camera=0,hsvfilter=[0],masking=[0]):
    cap = cv2.VideoCapture(camera)

    myColorFinder = ColorFinder(True)
    hsvVals="red"
    
    
    while True:
        success, img = cap.read() 
        img = cv2.flip(img,1)
        
        imgColor, mask = myColorFinder.update(img, hsvVals)
        
        img = cv2.resize(img, (0, 0), None, 0.7, 0.7)
        cv2.imshow("Image", img)
        cv2.imshow("ImageColor", imgColor)    
        k = cv2.waitKey(5) & 0xFF
        if k == 27:
            cap.release()
            cv2.destroyAllWindows()
            break
    print("tekan ESC untuk keluar dari kamera")
    show_webcam(mirror=mirror,
                camera=camera,
                hsvfilter=hsvfilter,
                masking=masking,
                )
    input("tekan ENTER untuk keluar")

def tulis(frame,location,text):
    font                   = cv2.FONT_HERSHEY_SIMPLEX
    fontScale              = .5
    fontColor              = (0,255,0)
    lineType               = 2
    cv2.putText(frame,text,location,font,fontScale,fontColor,lineType)

def show_webcam(mirror=False,camera=0,hsvfilter=0,masking=0,countour=0):
    font = cv2.FONT_HERSHEY_SIMPLEX
    location = (10,20)
    fontScale = .5
    fontColor = (0,255,0)
    lineType = 2
    
    
    cam = cv2.VideoCapture(camera)
    myColorFinder = ColorFinder(False)
    
    cx = 0
    cy = 0
    x_cor = 0
    y_cor = 0
    #   INTRUKSI!!!

            #   taruh preset yang dipakai di paling bawah 
            #   EDIT ATAU TAMBAH PRESET BARU JIKA PERLU PENYESUAIAN ATAU SELESAI KALIBRASI 
            #   edit atau tambah preset baru jika perlu penyesuaian atau selesai kalibrasi

            #   PRESET!
    #jingga
    hsvVals= {'hmin': 164, 'smin': 32, 'vmin': 0, 'hmax': 179, 'smax': 255, 'vmax': 255}

    
    while True:
        _, frameori = cam.read()
        if mirror: 
            frameori = cv2.flip(frameori, 1)
        frame = frameori.copy()
        # frame hsv
        hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        # mencari warna objek
        imgColor, mask = myColorFinder.update(frame, hsvVals)
        # mencari objek dengan countour
        imgContours, contours = cvzone.findContours(frame, mask, minArea=500)
        if contours:
            #titik tengah countour
            cx,cy = contours[0]['center']
            cv2.circle(imgContours, (cx,cy),5,(0,255,0),cv2.FILLED)
            cv2.circle(frame, (cx,cy),5,(0,255,0),cv2.FILLED)
           # print(cx,cy)
        
        x_cor = cx - 320
        y_cor = 240 - cy
        tresh_coor = 30
       
        if( x_cor > tresh_coor and y_cor > tresh_coor):
            print("kanan atas")
            arah="kanan atas"
        elif( x_cor < -tresh_coor and y_cor > tresh_coor):
            print("kiri atas")
            arah="kiri atas"
        elif( x_cor > tresh_coor and y_cor < -tresh_coor):
            print("kanan bawah")
            arah="kanan bawah"
        elif( x_cor < -tresh_coor and y_cor < -tresh_coor):
            print("kiri bawah")
            arah="kiri bawah"
        elif( y_cor > 0 and y_cor > tresh_coor):
            print("atas")
            arah="atas"
        elif( y_cor < 0 and y_cor < -tresh_coor):
            print("bawah")
            arah="bawah"
        else :
            if( x_cor > 0 and x_cor > tresh_coor ):
                print("kanan")
                arah="kanan"
            elif( x_cor < 0 and x_cor < -tresh_coor):
                 print("kiri")
                 arah="kiri"
            else:
                arah="tengah"
                print("tengah")

        frame = cv2.line(frame,((320 - tresh_coor),0),((320 - tresh_coor),480),(255,0,0),5)
        frame = cv2.line(frame,((320 + tresh_coor),0),((320 + tresh_coor),480),(255,0,0),5)
        frame = cv2.line(frame,(0,(240 - tresh_coor)),(640,(240 - tresh_coor)),(255,0,0),5)
        frame = cv2.line(frame,(0,(240 + tresh_coor)),(640,(240 + tresh_coor)),(255,0,0),5)
        
        tulis(frame,(10,20),'Koordinat')
        tulis(frame,(10,40),'%d,%d'%(x_cor,y_cor))
        tulis(frame,(10,60),f'arah : {arah}')
        
        frame = cv2.resize(frame, (640, 480))
        if masking:
            cv2.imshow('masking', mask)
        if hsvfilter:
            cv2.imshow('filter', imgContours)
        if countour:
            cv2.imshow('contour', imgContours)
        cv2.imshow('kamera', frame)
        if cv2.waitKey(1) == 27: 
            break
    cv2.destroyAllWindows()

def main():
    #   INTRUKSI!!!!
    #   mirror untuk membalik kamera jika memakai webcam laptop
    #   camera 0 untuk webcam, 1 untuk kamera eksternal, 0 jika kamera internal rusak dan mempunyai kamera eksternal
    #   trackbar 1 untuk memulai program dengan kalibrasi
    #   trackbar 0 untuk memulai program tanpa kalibrasi
    #   hsvfilter jika 1 akan membuat jendela filter
    #   masking jika 1 akan membuat jendela masking
    #   pergi ke line 78 untuk mengatur hsv value sehabis menjalankan mode trackbar/kalibrasi
    
    mirror=True
    camera=0
    trackbar=1
    hsvfilter=0
    countour=1
    masking=1
    if trackbar:
        print("tekan ESC untuk menyelesaikan kalibrasi")
        track_bar(mirror=mirror,camera=camera,hsvfilter=hsvfilter,masking=masking)
    else:
        show_webcam(mirror=mirror,camera=camera,hsvfilter=hsvfilter,masking=masking,countour=countour)
        print("tekan ESC untuk keluar")

if __name__ == '__main__':
    main()
